create function update_idea_in_city(changed_city_id integer) returns void
    language plpgsql
as
$$
declare
    last_date date;
    last_idea integer;
begin
    select max(date) into last_date from poll where city_id = changed_city_id;
    select idea into last_idea from poll where date = last_date and city_id = changed_city_id;
    update city set idea = last_idea where city.id = changed_city_id;
end;
$$;

alter function update_idea_in_city(integer) owner to s264484;

