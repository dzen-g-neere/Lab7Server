create function update_city_statistic() returns trigger
    language plpgsql
as
$$
declare
    city_food      integer;
    city_materials integer;
    city_money     integer;
    city_arms      integer;
begin
    ---при insert вставляются новые данные, при update вставляются новые и удаляются старые, при delete удаляются старые
    if (tg_op = 'INSERT' or tg_op = 'UPDATE') then
        select food into city_food from city where city.id = new.city_id;
        select materials into city_materials from city where city.id = new.city_id;
        select money into city_money from city where city.id = new.city_id;
        select arms into city_arms from city where city.id = new.city_id;
        city_food = city_food - new.food_dec + new.food_inc;
        city_materials = city_materials - new.materials_dec + new.materials_inc;
        city_money = city_money - new.money_dec + new.money_inc;
        city_arms = city_arms - new.arms_dec + new.arms_inc;
        update city
        set food      = city_food,
            money     = city_money,
            materials = city_materials,
            arms      = city_arms
        where city.id = new.city_id;
    end if;
    if (tg_op = 'UPDATE' or tg_op = 'DELETE') then
        select food into city_food from city where city.id = old.city_id;
        select materials into city_materials from city where city.id = old.city_id;
        select money into city_money from city where city.id = old.city_id;
        select arms into city_arms from city where city.id = old.city_id;
        city_food = city_food + old.food_dec - old.food_inc;
        city_materials = city_materials + old.materials_dec - old.materials_inc;
        city_money = city_money + old.money_dec - old.money_inc;
        city_arms = city_arms + old.arms_dec - old.arms_inc;
        update city
        set food      = city_food,
            money     = city_money,
            materials = city_materials,
            arms      = city_arms
        where city.id = old.city_id;
        return old;
    end if;
    return new;
end;
$$;

alter function update_city_statistic() owner to s264484;

