create function add_new_combat_union_by_soldier() returns trigger
    language plpgsql
as
$$
begin
    --- если добавленная профессия солдат -> добавляем запись в combat unit
    if (get_profession_by_id(new.profession_id) like 'soldier') then
        -- если в таблице нет нужно записи по человека
        insert into combat_unit (land_id, soldier_id, combat_dragon_id)
        values (get_land_id_by_citizen_id(new.citizen_id),
                new.citizen_id,
                null
               );
    end if;
    return new;
end;
$$;

alter function add_new_combat_union_by_soldier() owner to s264484;

