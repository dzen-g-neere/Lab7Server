create function check_dates_if_battle_changes() returns trigger
    language plpgsql
as
$$
declare
    war_start_date     date;
    war_finish_date    date;
    battle_start_date  date;
    battle_finish_date date;
begin
    battle_start_date = new.start_date;
    battle_finish_date = new.finish_date;
    select start_date into war_start_date from war where id = new.war_id;
    select finish_date into war_finish_date from war where id = new.war_id;
    if (war_start_date > battle_start_date) then
        raise exception 'Начало битвы % не может быть раньше начала войны %', new.id, new.war_id;
    end if;
    if (war_finish_date < battle_finish_date) then
        raise exception 'Война % не может закончиться раньше битвы %', new.war_id, new.id;
    end if;
    return new;
end;
$$;

alter function check_dates_if_battle_changes() owner to s264484;

