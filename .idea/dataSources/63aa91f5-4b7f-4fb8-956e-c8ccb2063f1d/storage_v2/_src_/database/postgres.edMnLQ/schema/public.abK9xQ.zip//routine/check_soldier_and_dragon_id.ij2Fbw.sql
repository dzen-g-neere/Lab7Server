create function check_soldier_and_dragon_id() returns trigger
    language plpgsql
as
$$
begin
    ---soldier должен иметь ту же land_id
    if (new.soldier_id is not null) then
        perform *
        from citizen
                 inner join city on city_id = city.id
                 inner join citizen_profession cp on citizen.id = cp.citizen_id
        where citizen.id = new.soldier_id
          and land_id = new.land_id
          and cp.profession_id = 3;
        if not FOUND then
            raise exception 'Citizen % has another land_id or job', new.soldier_id;
        end if;
    end if;
    ---dragon должен иметь ту же land_id
    if (new.combat_dragon_id is not null) then
        perform * from dragon where dragon.id = new.combat_dragon_id and dragon.land_id = new.land_id;
        if not FOUND then
            raise exception 'Dragon has another land_id';
        end if;
    end if;
    ---dragon and soldier должны быть связаны
    if (new.combat_dragon_id is not null and new.soldier_id is not null) then
        perform * from citizen where citizen.id = new.soldier_id and citizen.dragon_id = new.combat_dragon_id;
        if not FOUND then
            raise exception 'Dragon and soldier are not connected';
        end if;
    end if;


    -- при добавлении записи соединяем две разрозненные записи одного unit
    if (tg_op = 'INSERT') then
        declare
            is_has_dragon_in_combat_unit boolean;
            is_has_citizen_in_combat_unit boolean;
        begin
            --- было добавлено (dragon_id, null)
            if (new.combat_dragon_id is not null) then
                is_has_citizen_in_combat_unit = exists(select * from combat_unit
                                                       where combat_unit.soldier_id = get_citizen_of_dragon(new.combat_dragon_id));
                -- если в combat_unit есть владелец дракона, то удаляем эту запись и приписываем soldier к новой
                raise notice '%', is_has_citizen_in_combat_unit;

                if (is_has_citizen_in_combat_unit) then
                    begin
                        delete from combat_unit where combat_unit.soldier_id = get_citizen_of_dragon(new.combat_dragon_id);
                        new.soldier_id = get_citizen_of_dragon(new.combat_dragon_id);
                    end;
                end if;
            end if;

            --- было добавлено (soldier_id, null)
            if (new.soldier_id is not null) then

                is_has_dragon_in_combat_unit = exists(select * from combat_unit
                                                      where combat_unit.combat_dragon_id = get_dragon_of_citizen(new.soldier_id));
                -- если в combat_unit есть дракона, то удаляем эту запись и приписываем soldier к новой
                raise notice 'si dragon in combat_unit%', is_has_dragon_in_combat_unit;
                if (is_has_dragon_in_combat_unit) then
                    begin
                        delete from combat_unit where combat_unit.combat_dragon_id = get_dragon_of_citizen(new.soldier_id);
                        new.combat_dragon_id = get_dragon_of_citizen(new.soldier_id);
                    end;
                end if;
            end if;
        end;
    end if;






    return new;
end;
$$;

alter function check_soldier_and_dragon_id() owner to s264484;

