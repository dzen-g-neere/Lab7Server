create function check_only_one_jarl_and_konungr() returns trigger
    language plpgsql
as
$$
declare
    konungr_count integer;
    jarl_count    integer;
    index         integer;
begin
    if (new.social_group = 'konungr') then
        for index in
            ---идем по городам в этой же стране
            select id
            from city
            where land_id in (
                select land_id
                from city
                where id = new.city_id)
            loop
                select count(*) into konungr_count from citizen where social_group = 'konungr' and city_id = index;
                if (konungr_count = 1) then
                    raise exception 'В государстве может быть только один конунг';
                end if;
            end loop;
        return new;
    end if;
    if (new.social_group = 'jarl') then
        select count(*) into jarl_count from citizen where social_group = 'jarl' and new.city_id = city_id;
        if (jarl_count = 1) then
            raise exception 'В городе может быть только один ярл';
        else
            return new;
        end if;
    end if;


    --     -- добавляем данные в combat_unit
--     if (tg_op = 'INSERT' and new.current_profession_id = 3) then
--         --если у человека есть дракон
--         if (new.dragon_id is not null) then
--             update combat_unit set soldier_id = new.current_profession_id where dragon_id = new.dragon_id;
--         else
--             insert into combat_unit (id, land_id, soldier_id, combat_dragon_id)
--             values (default, new.)
--         end if;
--     end if;
    return new;
end;
$$;

alter function check_only_one_jarl_and_konungr() owner to s264484;

