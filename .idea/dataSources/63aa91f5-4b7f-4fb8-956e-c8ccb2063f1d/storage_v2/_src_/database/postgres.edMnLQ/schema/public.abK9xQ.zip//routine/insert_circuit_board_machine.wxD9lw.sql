create function insert_circuit_board_machine(ok_count integer, broken_count integer, discomissioned_count integer) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
begin
    for i in 1..ok_count loop
         insert into circuit_board_machine(assembly_date, work_hrs, area, state) values (random_past(10), (random() * 500 + 0)::real,
                                                  (random() * 100 + 1)::real, 'ok');
    end loop;
    for i in 1..broken_count loop
        insert into circuit_board_machine(assembly_date, work_hrs, area, state) values (random_past(10), (random() * 500 + 0)::real,
                                                  (random() * 100 + 1)::real, 'broken');
    end loop;
    for i in 1..discomissioned_count loop
        insert into circuit_board_machine(assembly_date, work_hrs, area, state) values (random_past(10), (random() * 500 + 0)::real,
                                                  (random() * 100 + 1)::real, 'decommissioned');
    end loop;
end;
$$;

alter function insert_circuit_board_machine(integer, integer, integer) owner to s264429;

