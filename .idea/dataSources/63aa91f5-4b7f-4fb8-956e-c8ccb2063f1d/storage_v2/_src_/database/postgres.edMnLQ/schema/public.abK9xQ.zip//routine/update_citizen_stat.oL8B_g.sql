create function update_citizen_stat() returns trigger
    language plpgsql
as
$$
declare
    city_soldier_count integer;
    index              integer;
begin
    ---считаем количество солдат по городам
    for index in
        select id from city
        loop
            select count(*) into city_soldier_count from citizen where index = city_id and current_profession_id = 3;
            update city set soldier_count = city_soldier_count where city.id = index;
        end loop;
    if (tg_op = 'DELETE') then
        return old;
        --    else
--        ---если профессия не записана в citizen_profession, добавляем ее туда
--        perform * from citizen_profession where citizen_id = new.id and profession_id = new.current_profession_id;
--        if (not FOUND and new.current_profession_id is not null) then
--            insert into citizen_profession values (new.id, new.current_profession_id);
--        end if;
    end if;
    return new;
end;
$$;

alter function update_citizen_stat() owner to s264484;

