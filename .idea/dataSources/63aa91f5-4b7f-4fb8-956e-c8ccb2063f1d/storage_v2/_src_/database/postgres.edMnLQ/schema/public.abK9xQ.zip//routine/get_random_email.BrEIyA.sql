create function get_random_email(fname character varying, lname character varying) returns character varying
    language plpgsql
as
$$
declare
    result varchar := '';
    domains varchar[] := array[
        'google.com',
        'yandex.ru',
        'yahoo.com',
        'hotmail.com',
        'mail.ru',
        'protonmail.com',
        'icloud.com'
    ];
begin
    result := result ||
              substring(lower(fname) from 1 for 1) ||
              lower(lname) ||
              (random()*999)::integer ||
              '@' ||
              domains[(random()*array_length(domains, 1))::int];
    return result;
end;
$$;

alter function get_random_email(varchar, varchar) owner to s264429;

